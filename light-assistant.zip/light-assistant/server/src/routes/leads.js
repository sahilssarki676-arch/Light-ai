import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { requireSupabase } from "../services/supabase.js";

export const leadsRouter = Router();
leadsRouter.use(requireAuth);

// GET /api/leads — list all leads for the current user
leadsRouter.get("/", async (req, res) => {
  const supabase = requireSupabase(res);
  if (!supabase) return;

  const { data, error } = await supabase
    .from("leads")
    .select("*")
    .eq("user_id", req.user.id)
    .order("created_at", { ascending: false });

  if (error) return res.status(500).json({ error: error.message });
  res.json({ leads: data });
});

// POST /api/leads — create a lead
leadsRouter.post("/", async (req, res) => {
  const supabase = requireSupabase(res);
  if (!supabase) return;

  const { business_name, business_type, contact, status, notes, follow_up_at, value } = req.body;
  if (!business_name) return res.status(400).json({ error: "`business_name` is required" });

  const { data, error } = await supabase
    .from("leads")
    .insert({
      user_id: req.user.id,
      business_name,
      business_type: business_type ?? null,
      contact: contact ?? null,
      status: status ?? "new",
      notes: notes ?? null,
      follow_up_at: follow_up_at ?? null,
      value: value ?? null,
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json({ lead: data });
});

// PATCH /api/leads/:id — update a lead (status, notes, follow-up, etc.)
leadsRouter.patch("/:id", async (req, res) => {
  const supabase = requireSupabase(res);
  if (!supabase) return;

  const { data, error } = await supabase
    .from("leads")
    .update(req.body)
    .eq("id", req.params.id)
    .eq("user_id", req.user.id)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json({ lead: data });
});

// DELETE /api/leads/:id
leadsRouter.delete("/:id", async (req, res) => {
  const supabase = requireSupabase(res);
  if (!supabase) return;

  const { error } = await supabase.from("leads").delete().eq("id", req.params.id).eq("user_id", req.user.id);
  if (error) return res.status(500).json({ error: error.message });
  res.status(204).end();
});
