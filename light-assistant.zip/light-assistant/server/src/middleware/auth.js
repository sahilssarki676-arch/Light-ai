import { supabaseAdmin } from "../services/supabase.js";

/**
 * Verifies the Supabase access token sent from the client in the
 * `Authorization: Bearer <token>` header, and attaches `req.user`.
 *
 * The frontend gets this token automatically from `supabase.auth.getSession()`
 * after login (see web/src/services/api.ts).
 */
export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;

    if (!token) {
      return res.status(401).json({ error: "Missing auth token" });
    }

    const { data, error } = await supabaseAdmin.auth.getUser(token);
    if (error || !data?.user) {
      return res.status(401).json({ error: "Invalid or expired session" });
    }

    req.user = data.user;
    next();
  } catch (err) {
    console.error("Auth check failed:", err.message);
    res.status(401).json({ error: "Authentication failed" });
  }
}
