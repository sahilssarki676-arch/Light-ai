import dotenv from "dotenv";
dotenv.config();

function required(name, fallback = undefined) {
  const value = process.env[name] ?? fallback;
  return value;
}

export const env = {
  port: Number(process.env.PORT) || 5000,
  clientOrigin: required("CLIENT_ORIGIN", "http://localhost:5173"),

  aiProvider: required("AI_PROVIDER", "openai"),
  openaiApiKey: required("OPENAI_API_KEY", ""),
  openaiModel: required("OPENAI_MODEL", "gpt-4o-mini"),
  geminiApiKey: required("GEMINI_API_KEY", ""),
  geminiModel: required("GEMINI_MODEL", "gemini-1.5-flash"),

  supabaseUrl: required("SUPABASE_URL", ""),
  supabaseServiceKey: required("SUPABASE_SERVICE_ROLE_KEY", ""),

  jwtSecret: required("JWT_SECRET", "dev-secret-change-me"),
};

export function assertAIConfigured() {
  if (env.aiProvider === "openai" && !env.openaiApiKey) {
    return { ok: false, message: "OPENAI_API_KEY is missing in server/.env" };
  }
  if (env.aiProvider === "gemini" && !env.geminiApiKey) {
    return { ok: false, message: "GEMINI_API_KEY is missing in server/.env" };
  }
  return { ok: true };
}
