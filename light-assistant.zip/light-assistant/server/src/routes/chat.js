import { Router } from "express";
import { generateReply } from "../services/aiProvider.js";
import { assertAIConfigured } from "../config/env.js";
import { requireAuth } from "../middleware/auth.js";
import { requireSupabase } from "../services/supabase.js";
import { aiLimiter } from "../middleware/rateLimit.js";

export const chatRouter = Router();

/**
 * POST /api/chat
 * Body: { messages: [{role, content}], conversationId?: string }
 * Requires auth so replies can be tied to a user's memory.
 */
chatRouter.post("/", requireAuth, aiLimiter, async (req, res) => {
  const configCheck = assertAIConfigured();
  if (!configCheck.ok) {
    return res.status(500).json({ error: configCheck.message });
  }

  const { messages, conversationId } = req.body;
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "`messages` must be a non-empty array" });
  }

  try {
    const { text } = await generateReply(messages);

    // Best-effort memory persistence — chat still works even if Supabase isn't set up yet
    const supabase = requireSupabase({ status: () => ({ json: () => {} }) });
    if (supabase && conversationId) {
      const lastUserMsg = [...messages].reverse().find((m) => m.role === "user");
      await supabase.from("conversation_messages").insert([
        { conversation_id: conversationId, user_id: req.user.id, role: "user", content: lastUserMsg?.content ?? "" },
        { conversation_id: conversationId, user_id: req.user.id, role: "assistant", content: text },
      ]);
    }

    res.json({ reply: text });
  } catch (err) {
    console.error("Chat generation failed:", err.message);
    res.status(502).json({ error: "Light couldn't generate a reply right now. Please try again." });
  }
});
