import rateLimit from "express-rate-limit";

// General API limiter — generous, just to blunt abuse/scraping
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please slow down and try again shortly." },
});

// Tighter limiter for AI calls specifically, since these cost money per request
export const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "You're sending messages too quickly. Wait a moment and try again." },
});
