import { createClient } from "@supabase/supabase-js";
import { env } from "../config/env.js";

// Service-role client — full DB access, server-side only. Never send this key to the browser.
export const supabaseAdmin =
  env.supabaseUrl && env.supabaseServiceKey
    ? createClient(env.supabaseUrl, env.supabaseServiceKey, {
        auth: { autoRefreshToken: false, persistSession: false },
      })
    : null;

export function requireSupabase(res) {
  if (!supabaseAdmin) {
    res.status(500).json({
      error: "Supabase is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in server/.env",
    });
    return null;
  }
  return supabaseAdmin;
}
