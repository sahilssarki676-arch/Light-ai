import { Router } from "express";
import { generateReply } from "../services/aiProvider.js";
import { assertAIConfigured } from "../config/env.js";
import { requireAuth } from "../middleware/auth.js";
import { aiLimiter } from "../middleware/rateLimit.js";
import { requireSupabase } from "../services/supabase.js";

export const templatesRouter = Router();

/**
 * POST /api/templates/generate
 * Body: { businessType, businessName, channel, tone?, extraContext? }
 * Uses the AI provider to personalize a base template (client sends the base copy
 * from businessTemplates.ts) for a specific lead.
 */
templatesRouter.post("/generate", requireAuth, aiLimiter, async (req, res) => {
  const configCheck = assertAIConfigured();
  if (!configCheck.ok) return res.status(500).json({ error: configCheck.message });

  const { businessType, businessName, channel, tone, extraContext, baseTemplate } = req.body;
  if (!businessType || !channel) {
    return res.status(400).json({ error: "`businessType` and `channel` are required" });
  }

  const prompt = `Write a ${channel} outreach message from a freelance web developer named Sahil
to a ${businessType.replace(/-/g, " ")}${businessName ? ` called "${businessName}"` : ""}, offering
web development / website services. Tone: ${tone || "friendly and professional"}. Keep it native
to the ${channel} format (short for WhatsApp/Instagram DM, a subject + body for Email, slightly
more formal for LinkedIn). ${extraContext ? `Extra context: ${extraContext}.` : ""}
${baseTemplate ? `Use this as a starting structure, but personalize it:\n${baseTemplate}` : ""}
Return only the message text, no explanation.`;

  try {
    const { text } = await generateReply([{ role: "user", content: prompt }]);

    // Log it against the lead, if the client is tracking one
    const supabase = requireSupabase({ status: () => ({ json: () => {} }) });
    if (supabase && req.body.leadId) {
      await supabase.from("messages").insert({
        user_id: req.user.id,
        lead_id: req.body.leadId,
        channel,
        content: text,
      });
    }

    res.json({ message: text });
  } catch (err) {
    console.error("Template generation failed:", err.message);
    res.status(502).json({ error: "Couldn't generate the message right now. Please try again." });
  }
});
