import { env } from "../config/env.js";

/**
 * Modular AI layer. Add a new provider by writing a `callX(messages, opts)` function
 * with the same shape (return { text }) and adding a branch in `generateReply`.
 * Everything else in the app (routes, frontend) only ever calls `generateReply`.
 */

const LIGHT_SYSTEM_PROMPT = `You are Light, a warm, sharp, human-sounding AI assistant built by
Sahil Sarki, a freelance web developer. You speak naturally in English and Nepali — mirror
whichever language (or mix, "Namglish") the user writes or speaks in, unless they ask you to
switch. Keep replies conversational and concise for voice, more detailed for text when useful.

You also act as Sahil's business assistant: help him write outreach messages, plan follow-ups,
and think through client work. When asked to draft outreach, be specific to the business type
(furniture shop, optical shop, salon, hotel, etc.) and the channel (WhatsApp/Email/Instagram/
Facebook/LinkedIn) — match tone and length to that channel.

Never invent facts about Sahil's past work beyond what you're told in the conversation.`;

async function callOpenAI(messages) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${env.openaiApiKey}`,
    },
    body: JSON.stringify({
      model: env.openaiModel,
      messages: [{ role: "system", content: LIGHT_SYSTEM_PROMPT }, ...messages],
      temperature: 0.7,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenAI error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  return { text: data.choices?.[0]?.message?.content?.trim() || "" };
}

async function callGemini(messages) {
  // Gemini expects "user"/"model" roles and no system message in the same array —
  // we fold the system prompt into the first user turn instead.
  const contents = messages.map((m, i) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: i === 0 ? `${LIGHT_SYSTEM_PROMPT}\n\n${m.content}` : m.content }],
  }));

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${env.geminiModel}:generateContent?key=${env.geminiApiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
  return { text: text.trim() };
}

/**
 * @param {{role: 'user'|'assistant', content: string}[]} messages
 * @returns {Promise<{text: string}>}
 */
export async function generateReply(messages) {
  if (env.aiProvider === "gemini") return callGemini(messages);
  return callOpenAI(messages);
}
