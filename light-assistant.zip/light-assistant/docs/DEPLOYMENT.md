# Deploying Light

Light is two apps: `web/` (static frontend) and `server/` (Node API). Deploy them separately.

---

## 1. Backend (`server/`)

The backend needs to run as a long-lived Node process (not a static host), so use **Render** or
**Railway** (both have simple free tiers).

### Render
1. Push this repo to GitHub.
2. New → Web Service → connect the repo, root directory `server`.
3. Build command: `npm install`. Start command: `npm start`.
4. Add environment variables from `server/.env.example` (Environment tab).
5. Deploy. Note the public URL, e.g. `https://light-server.onrender.com`.

### Railway
1. New Project → Deploy from GitHub repo → set root directory to `server`.
2. Add the same environment variables.
3. Railway auto-detects `npm start`. Deploy and grab the public URL.

---

## 2. Frontend (`web/`)

### Vercel
1. Import the repo, set **Root Directory** to `web`.
2. Framework preset: Vite. Build command: `npm run build`. Output dir: `dist`.
3. Add env vars: `VITE_API_URL` (your deployed backend URL), `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
4. Deploy.

### Netlify
1. New site from Git → base directory `web`.
2. Build command: `npm run build`. Publish directory: `web/dist`.
3. Add the same env vars under Site settings → Environment variables.
4. Add a `web/public/_redirects` file with `/* /index.html 200` if you want deep-link routes
   (e.g. `/app/chat`) to work on refresh — Vercel handles this automatically, Netlify needs it explicit.

### GitHub Pages
GitHub Pages only serves static files and doesn't support client-side route rewrites well, so:
- Best fit: deploy the **Landing/Portfolio** pages here, and send people to Vercel/Netlify for the
  full app — or set `base: '/your-repo-name/'` in `vite.config.ts` and add a 404.html→index.html
  redirect trick if you want the whole SPA here.
- `npm run build` in `web/`, then push the `dist/` folder to a `gh-pages` branch (e.g. with the
  `gh-pages` npm package, or GitHub Actions).

---

## 3. Supabase

1. Run `server/src/db/schema.sql` in the Supabase SQL editor.
2. Authentication → URL Configuration: add your deployed frontend URL to **Redirect URLs** (needed
   for Google OAuth to redirect back correctly).
3. Authentication → Providers → Google: add your OAuth client ID/secret from Google Cloud Console.

---

## 4. Post-deploy checklist

- [ ] `server` env vars set, `/api/health` returns `{ status: "ok" }`
- [ ] `web` env vars point at the deployed `server` URL, not `localhost`
- [ ] Supabase schema applied, RLS policies active
- [ ] Google OAuth redirect URL matches your deployed domain
- [ ] Test sign-up → chat → create a lead → generate an outreach message end-to-end
- [ ] Install the PWA on an Android phone (Chrome menu → "Install app") and confirm mic/voice works
