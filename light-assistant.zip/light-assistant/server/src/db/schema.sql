-- Light AI Assistant — Supabase schema
-- Run this in the Supabase SQL editor (Project → SQL Editor → New query)

-- Extends auth.users with assistant preferences
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  voice_name text default 'default',
  language text default 'en' check (language in ('en', 'ne', 'auto')),
  theme text default 'dark' check (theme in ('dark', 'light')),
  memory_enabled boolean default true,
  created_at timestamptz default now()
);

-- Leads / CRM
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  business_name text not null,
  business_type text, -- furniture, optical, electronics, interior-design, real-estate,
                       -- restaurant, gym, salon, school, hotel
  contact text,
  status text default 'new' check (status in ('new', 'contacted', 'replied', 'negotiating', 'client', 'lost')),
  notes text,
  follow_up_at timestamptz,
  value numeric default 0, -- deal value, used for the Revenue dashboard stat once status='client'
  created_at timestamptz default now()
);

-- Outreach messages generated per lead
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  lead_id uuid references leads(id) on delete set null,
  channel text not null check (channel in ('whatsapp', 'email', 'instagram', 'facebook', 'linkedin')),
  content text not null,
  created_at timestamptz default now()
);

-- Chat conversations (for grouping) + messages (for memory/context)
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  title text default 'New chat',
  created_at timestamptz default now()
);

create table if not exists conversation_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade not null,
  user_id uuid references auth.users(id) on delete cascade not null,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz default now()
);

-- Row Level Security — each user only ever sees their own rows
alter table profiles enable row level security;
alter table leads enable row level security;
alter table messages enable row level security;
alter table conversations enable row level security;
alter table conversation_messages enable row level security;

create policy "profiles: owner read/write" on profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

create policy "leads: owner read/write" on leads
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "messages: owner read/write" on messages
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "conversations: owner read/write" on conversations
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "conversation_messages: owner read/write" on conversation_messages
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Helpful indexes
create index if not exists leads_user_idx on leads(user_id);
create index if not exists messages_lead_idx on messages(lead_id);
create index if not exists conv_messages_conv_idx on conversation_messages(conversation_id);
