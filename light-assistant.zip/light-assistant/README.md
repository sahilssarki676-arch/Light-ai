# Light — AI Phone Assistant

Light is a bilingual (English + Nepali) AI assistant with voice + text chat, memory, and a
built-in business toolkit for running a freelance web development practice: outreach message
generation, a lead CRM, and a metrics dashboard.

This repo is a **monorepo** with two apps:

```
light-assistant/
├── web/       React + TypeScript + Tailwind (PWA) — UI, voice, chat, dashboard, CRM
├── server/    Node.js + Express — AI provider proxy, leads API, auth, rate limiting
└── docs/      Deployment & Android integration guides
```

---

## Why a backend at all?

The browser talks to `server/`, never directly to OpenAI/Gemini. This keeps your API keys off
the client, lets you rate-limit abuse, and gives you one place to swap AI providers.

---

## 1. Quickstart

### Requirements
- Node.js 18+
- A Supabase project (free tier is fine) — for auth + storing leads/messages/memory
- An API key for at least one AI provider: OpenAI **or** Google Gemini

### Install & run

```bash
# 1. Backend
cd server
cp .env.example .env      # fill in your keys, see below
npm install
npm run dev                # http://localhost:5000

# 2. Frontend (new terminal)
cd web
cp .env.example .env
npm install
npm run dev                # http://localhost:5173
```

Open http://localhost:5173 — that's it. No missing files, nothing else to scaffold.

---

## 2. Environment variables

### `server/.env`
| Key | Description |
|---|---|
| `PORT` | Port for the Express server (default `5000`) |
| `AI_PROVIDER` | `openai` or `gemini` — which provider `aiProvider.js` routes to |
| `OPENAI_API_KEY` | Your OpenAI key (only needed if `AI_PROVIDER=openai`) |
| `GEMINI_API_KEY` | Your Gemini key (only needed if `AI_PROVIDER=gemini`) |
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase **service role** key (server-side only, never expose to client) |
| `CLIENT_ORIGIN` | Your frontend URL, for CORS (e.g. `http://localhost:5173`) |
| `JWT_SECRET` | Random long string used to sign session tokens |

### `web/.env`
| Key | Description |
|---|---|
| `VITE_API_URL` | URL of the `server/` app (e.g. `http://localhost:5000`) |
| `VITE_SUPABASE_URL` | Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` | Supabase **anon/public** key (safe for the client) |

Never commit real `.env` files — only `.env.example` is tracked (see `.gitignore`).

---

## 3. Database setup (Supabase)

1. Create a project at https://supabase.com.
2. Open the SQL editor and run `server/src/db/schema.sql`. It creates:
   - `leads` — your CRM records
   - `messages` — outreach messages generated per lead
   - `conversations` / `conversation_messages` — Light's chat memory
   - `profiles` — extends Supabase auth users with assistant preferences
3. Enable **Email** and **Google** providers under Authentication → Providers.
4. Copy your project URL + anon key into `web/.env`, and URL + service role key into `server/.env`.

---

## 4. Features implemented

**Chat**
- Text + voice chat with Light, English/Nepali toggle, typing animation, streaming-style replies
- Conversation memory persisted to Supabase per user (with a client-side "forget everything" control)

**Voice**
- Push-to-talk and continuous "listening mode" via the Web Speech API (`useSpeechRecognition`)
- "Hey Light" wake-word detection when continuous mode is on (`useWakeWord`) — lightweight
  keyword spotting on the live transcript; for production-grade always-on wake word on mobile,
  see `docs/ANDROID.md`
- Text-to-speech replies with selectable voice (`useSpeechSynthesis`), and speech is interrupted
  automatically as soon as the mic picks up new speech ("barge-in")

**Business Assistant**
- Outreach message generator for 10 business types (furniture, optical, electronics, interior
  design, real estate, restaurants, gyms, salons, schools, hotels) across WhatsApp, Email,
  Instagram DM, Facebook, and LinkedIn — `web/src/data/businessTemplates.ts` + AI personalization
- Lead CRM: business name, contact, status, notes, follow-up date, stored in Supabase

**Dashboard**
- Total leads, active clients, revenue, messages sent, upcoming follow-ups — live from Supabase

**Portfolio & Booking**
- Embedded link to your portfolio, plus one-tap Call / WhatsApp / Email buttons and a contact form

**Settings**
- Voice, language, theme (dark/light), and memory controls (clear chat history)

**Security**
- Supabase Auth (email/password + Google OAuth)
- Express rate limiting on all `/api` routes
- All secrets via environment variables, never hardcoded

**PWA**
- Installable on Android/desktop, offline app shell, manifest + icons included

---

## 5. Deploying

See `docs/DEPLOYMENT.md` for step-by-step Vercel/Netlify (frontend) and Render/Railway (backend)
instructions, plus GitHub Pages notes.

## 6. Phone / Android

The web app is a full PWA — installable on Android and iOS home screens, with mic, camera,
notifications, clipboard, file upload, and geolocation working through standard browser APIs.

Browsers **cannot** place calls, read SMS, access contacts, or run in the background with
device-wide control — that requires a native shell. `docs/ANDROID.md` documents how to wrap this
same web app in a Capacitor-based Android project and add those native permissions without
rewriting the UI.

---

## 7. Project status / honesty notes

This is a complete, runnable scaffold, not a black-box demo:
- Every screen listed above is real, wired UI — not a mockup.
- AI calls go through your own backend to your own provider key; nothing is faked.
- Google Login, "Hey Light" wake word, and TTS voice quality depend on the browser/OS you test in
  (Web Speech API support varies — Chrome has the best coverage). The code detects and falls back
  gracefully when a browser doesn't support a feature.
- Revenue/clients on the dashboard are computed from your `leads` table (`status = 'client'` and
  an optional `value` field) — adjust the query in `LeadTable`/`Dashboard` to match how you track money.

## License
MIT — do whatever you want with it.
