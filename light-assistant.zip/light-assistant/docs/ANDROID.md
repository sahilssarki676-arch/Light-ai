# Light on Android — beyond the browser

The web app (`web/`) already works great as an installed PWA: mic, camera, notifications,
clipboard, file uploads, and geolocation all work through standard browser APIs, no extra project
needed. Install it via Chrome → menu → "Install app".

But a browser — even installed as a PWA — **cannot**:
- Place or receive phone calls
- Read or send SMS
- Access the contacts list
- Run a true always-on background service (e.g. wake-word listening with the screen off)
- Control other apps on the device

Those require a native Android permission model. Rather than rewriting the UI as a separate native
app, wrap this same web app in **Capacitor** (by the Ionic team) — it ships your existing React
build inside a real Android app, and gives you a bridge to call native Android APIs (and native
plugins can request permissions like `READ_SMS`, `CALL_PHONE`, `READ_CONTACTS`) from the same
TypeScript codebase.

## Setup outline

```bash
cd web
npm install @capacitor/core @capacitor/android
npx cap init "Light" "com.sahilsarki.light" --web-dir=dist
npm run build
npx cap add android
npx cap sync android
npx cap open android   # opens Android Studio
```

## Adding native permissions

1. In `android/app/src/main/AndroidManifest.xml`, add the permissions you need, e.g.:
   ```xml
   <uses-permission android:name="android.permission.CALL_PHONE" />
   <uses-permission android:name="android.permission.READ_SMS" />
   <uses-permission android:name="android.permission.READ_CONTACTS" />
   <uses-permission android:name="android.permission.RECORD_AUDIO" />
   ```
2. Request them at runtime (Android 6+ requires this in addition to the manifest entry) — either
   with a Capacitor community plugin (search `capacitor-android-permissions` or write a small
   custom plugin), or a native `PermissionsActivity` if you go fully custom.
3. Bridge native results back to the web app with a Capacitor plugin's JS API, e.g.
   `Contacts.getAll()`, and call it from `web/src/services/` the same way `api.ts` calls the backend.

## Always-on wake word ("Hey Light" with the screen off)

The browser-based wake word in `useWakeWord.ts` only works while the tab/PWA is open and the mic
is actively granted. For true always-on detection:
- Run a **foreground Android service** (required by Android for anything long-running with mic
  access) that uses an on-device wake-word engine (e.g. Porcupine, or Android's own
  `SpeechRecognizer` in a loop) and shows a persistent notification while listening — Android
  requires this for transparency and battery reasons.
- On detection, launch/foreground the Capacitor WebView and pass control to the same chat flow.

## What NOT to change

Keep all business logic, UI, and API calls in `web/src`. The Android project should only add:
- Capacitor config + native permission plugins
- The optional foreground wake-word service described above

This way, a bug fix or feature in the web app ships to both the PWA and the Android app with the
same `npm run build && npx cap sync android`.
