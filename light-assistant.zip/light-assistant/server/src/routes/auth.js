import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { requireSupabase } from "../services/supabase.js";

export const authRouter = Router();

// Login/signup/Google OAuth all happen client-side via Supabase Auth (web/src/context/AuthContext.tsx).
// This route just lets the frontend confirm the token it holds is still valid, and fetch/create
// the matching profile row for assistant preferences (voice, language, theme, memory).

authRouter.get("/me", requireAuth, async (req, res) => {
  const supabase = requireSupabase(res);
  if (!supabase) return;

  let { data: profile } = await supabase.from("profiles").select("*").eq("id", req.user.id).single();

  if (!profile) {
    const { data: created } = await supabase
      .from("profiles")
      .insert({ id: req.user.id, email: req.user.email })
      .select()
      .single();
    profile = created;
  }

  res.json({ user: { id: req.user.id, email: req.user.email }, profile });
});

authRouter.patch("/me", requireAuth, async (req, res) => {
  const supabase = requireSupabase(res);
  if (!supabase) return;

  const { data, error } = await supabase
    .from("profiles")
    .update(req.body)
    .eq("id", req.user.id)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.json({ profile: data });
});
