import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";

import { env } from "./config/env.js";
import { apiLimiter } from "./middleware/rateLimit.js";
import { chatRouter } from "./routes/chat.js";
import { leadsRouter } from "./routes/leads.js";
import { templatesRouter } from "./routes/templates.js";
import { authRouter } from "./routes/auth.js";

const app = express();

app.use(helmet());
app.use(cors({ origin: env.clientOrigin, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));
app.use("/api", apiLimiter);

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "light-server", time: new Date().toISOString() });
});

app.use("/api/auth", authRouter);
app.use("/api/chat", chatRouter);
app.use("/api/leads", leadsRouter);
app.use("/api/templates", templatesRouter);

// 404
app.use("/api", (_req, res) => res.status(404).json({ error: "Not found" }));

// Central error handler
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(env.port, () => {
  console.log(`⚡ Light server running on http://localhost:${env.port}`);
});
